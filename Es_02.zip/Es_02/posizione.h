#pragma once 

class posizione {

    public:

    //costruttori
    posizione();
    posizione(double x, double y, double z);
    posizione(const posizione& b);

    //distruttore
    ~posizione() {};

    //coordinate cartesiane
    void setX(double x) {p_x = x; };
    void setY(double y) {p_y = y; };
    void setZ(double z) {p_z = z; };
    double getX() const {return p_x; };
    double getY() const {return p_y; };
    double getZ() const {return p_z; };

    //coordinate polari e cilindriche
    double getR() const;
    double getPhi() const;
    double getTheta() const;
    double getRho() const;

    //calcolo distanza da un altro punto
    double distanza(const posizione& ) const;
    double distanza(const double x, const double y, const double z) const;
    
    protected:

    double p_x, p_y, p_z;

};