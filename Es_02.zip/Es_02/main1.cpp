#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <cmath>

#include "random.h"
#include "funzioni.h"

using namespace std;
 
int main (int argc, char *argv[]){

    // Il programma è relativo all'esercizio 1

    // Set up generatore numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2 ;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        }
        input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;

    // Creazine variabili
    const int M{10000};
    const int N{100};
    const int L{(int) M / N};
    double Gn{};

    array<double, N> ave;
    array<double, N> ave2;
    array<double, N> sum_prog;
    sum_prog.fill(0);
    array<double, N> sum2_prog;
    sum2_prog.fill(0);
    array<double, N> err_prog;

    // 02.1.1
    // Integrazione Monte Carlo via sampling a distribuzione uniforme    
    for(int i{}; i < N; i++){
        for(int j{}; j < L; j++)
            Gn += M_PI * 0.5 * cos(rnd.Rannyu(0, M_PI / 2));
        
        ave[i] = Gn / L;
        ave2[i] = pow(ave[i], 2);
        Gn = 0;
    }

    // Calcolo media e incertezza, scrittura dei risultati su file
    ofstream of;
    of.open("measures-uni.out");
    if(!of.is_open())
        cerr << "PROBLEM: Unable to open \"measures-uni.out\"" << endl;
    
    for(int i{}; i < N; i++){
        for(int j{}; j < i + 1; j++){
            sum_prog[i] += ave[j];
            sum2_prog[i] += ave2[j];
        }
        sum_prog[i] /= (i + 1);
        sum2_prog[i] /= (i + 1);
        err_prog[i] = error(sum_prog[i], sum2_prog[i], i); // Statistical uncertainty
        of << sum_prog[i] << " " << err_prog[i] << endl;
    }

    of.close();
    
    // 02.1.2
    // Integrazione Monte Carlo via importance sampling    
    for(int i{}; i < N; i++){
        for(int j{}; j < L; j++){
            double x{rnd.es2()};
            Gn += M_PI * 0.5 * cos(x * M_PI / 2) / (-2 * (x - 1));
        }

        ave[i] = Gn / L;
        ave2[i] = pow(ave[i], 2);
        Gn = 0;
    }

    // Calcolo media e incertezza, scrittura dei risultati su file
    sum_prog.fill(0);
    sum2_prog.fill(0);

    of.open("measures-imp.out");
    if(!of.is_open())
        cerr << "PROBLEM: Unable to open \"measures-imp.out\"" << endl;
    
    for(int i{}; i < N; i++){
        for(int j{}; j < i + 1; j++){
            sum_prog[i] += ave[j];
            sum2_prog[i] += ave2[j];
        }
        sum_prog[i] /= (i + 1);
        sum2_prog[i] /= (i + 1);
        err_prog[i] = error(sum_prog[i], sum2_prog[i], i); // Statistical uncertainty
        of << sum_prog[i] << " " << err_prog[i] << endl;
    }
   
    of.close();

    return 0;
}
