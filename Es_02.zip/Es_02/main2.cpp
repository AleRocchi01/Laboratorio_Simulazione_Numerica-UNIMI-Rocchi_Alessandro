#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

#include "funzioni.h"
#include "random.h"
#include "walker.h"

using namespace std;
 
int main (int argc, char *argv[]){

    // Il programma è relativo all'esercizio 2

    // Set up generatore numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2 ;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        }
        input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;

    // Variabili generali
    const int M{10000}; // Estrazioni
    const int N{100};   // Blocchi
    const int L{M / N}; // Lunghezza blocchi 
    
    vector<vector<double>> data;
    Walker wal;

    // Creo i percorsi

    for(int i{}; i < M; i++){

        vector<double> story;
        for(int j{}; j < N; j++){
            wal.orthonormal_walker(rnd);
            story.push_back(wal.getR()); // Storico dei raggi di un percorso
        }
        data.push_back(story);           // Vettore degli storici dei vari percorsi
        wal.reset();
    }

    // Analizzo e salvo i dati

    ofstream of;

    of.open("data2D.out");
   
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"data2D.out\"" << endl;

    double ave{};
    double ave2{};

    for(int i{}; i < N; i++){
        for(int j{}; j < N; j++){
            
            double dep{}; 
            for(int k{}; k < L; k++)
                dep += pow(data[j + k][i], 2);
            
            dep /= L;
            ave += sqrt(dep);
            ave2 += dep;
        }
        of << ave << " " << error(ave, ave2, N) << endl;
        ave = 0;
        ave2 = 0;
    }

    of.close();

    // caso continuo
    
    for(int i{}; i < M; i++){

        vector<double> story;
        for(int j{}; j < N; j++){
            wal.orthonormal_walker(rnd);
            story.push_back(wal.getR());
        }
        data[i] = story;
        wal.reset();
    }

    of.open("data2C.out");
   
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"data2C.out\"" << endl;

    for(int i{}; i < N; i++){
        for(int j{}; j < N; j++){
            
            double dep{}; 
            for(int k{}; k < L; k++)
                dep += pow(data[j + k][i], 2);
            
            dep /= L;
            ave += sqrt(dep);
            ave2 += dep;
        }
        of << ave << " " << error(ave, ave2, N) << endl;
        ave = 0;
        ave2 = 0;
    }

    of.close();


    return 0;
}
