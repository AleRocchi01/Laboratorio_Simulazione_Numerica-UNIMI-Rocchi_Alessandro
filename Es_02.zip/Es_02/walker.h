#pragma once

#include <cmath>
#include <vector>

#include "posizione.h"
#include "random.h"

using namespace std;

class Walker : public posizione
{
    private:
    int m_n_step{0}; // Numero di step effettuati
    double m_a{1.};  // Lunghezza del passo

    public:
    Walker() : posizione{} {}
    Walker(double x, double y, double z) : posizione{x, y, z} {}
    Walker(posizione& p) : posizione{p} {}
        
    ~Walker(){}
    void orthonormal_walker(Random& gen);
    void continuos_walker(Random& gen);
    void reset();

    int getStep();
    vector<double> state() const;
};
