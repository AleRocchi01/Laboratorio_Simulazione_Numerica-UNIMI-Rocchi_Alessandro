#include "posizione.h"
#include <cmath>

using namespace std;
 
posizione::posizione() : p_x{}, p_y{}, p_z{} {}

posizione::posizione(double x, double y, double z) : p_x{x}, p_y{y}, p_z{z} {}

posizione::posizione(const posizione& b) : p_x{b.getX()}, p_y{b.getY()}, p_z{b.getZ()} {}

double posizione::getR() const {

    return sqrt(pow(p_x, 2) + pow(p_y, 2) + pow(p_z, 2));    
}

double posizione::getPhi() const {

    return atan2(p_y, p_x);
}

double posizione::getTheta() const {

    return acos(p_z / getR());
}

double posizione::getRho()const {

    return sqrt(pow(p_x, 2) + pow(p_y, 2));
}

double posizione::distanza(const posizione& b) const {

    return sqrt( pow((p_x - b.getX()), 2) +
                 pow((p_y - b.getY()), 2) +
                 pow((p_z - b.getZ()), 2));
 
}

double posizione::distanza(const double x, const double y, const double z) const {

    return sqrt( pow((p_x - x), 2) +
                 pow((p_y - y), 2) +
                 pow((p_z - z), 2));
 
}
