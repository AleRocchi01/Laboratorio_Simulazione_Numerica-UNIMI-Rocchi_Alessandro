#include "walker.h"

void Walker::orthonormal_walker(Random &gen)
{
    // choosing a random direction
    int dir = (int)(gen.Rannyu(0., 6)); // its only values are 0, 1, 2, 3, 4, 5

    switch (dir)
    {
    case 0:
        p_x += m_a;
        break;
    case 1:
        p_x -= m_a;
        break;
    
    case 2:
        p_y += m_a;
        break;
    case 3:
        p_y -= m_a;
        break;

    case 4:
        p_z += m_a;
        break;
    case 5:
        p_z -= m_a;
        break;
    }

    m_n_step ++;
}

void Walker::continuos_walker(Random &gen)
{
    // estraggo sin_theta perché voglio che l'angolo solido [sin(theta) dtheta dphi] sia distribuito uniformemente
    double sin_theta = gen.Rannyu(0, 1);
    double phi = gen.Rannyu(0, 2*M_PI);

    p_x += m_a * sin_theta * cos(phi);
    p_y += m_a * sin_theta * sin(phi);
    p_z += m_a * sqrt(1-pow(sin_theta, 2));

    m_n_step ++;

}

void Walker::reset()
{
    p_x = 0;
    p_y = 0;
    p_z = 0;

    m_n_step = 0;
}

int Walker::getStep()
{
    return m_n_step;
}

vector<double> Walker::state() const
{
    vector<double> res{p_x, p_y, p_z};
    return res;
}
