#pragma once 

class Posizione {

    public:

    //costruttori
    Posizione();
    Posizione(double x, double y);
    Posizione(const Posizione& );

    //distruttore
    ~Posizione() {};

    //coordinate cartesiane
    void setX(double x) {p_x = x; };
    void setY(double y) {p_y = y; };
    double getX() const {return p_x; };
    double getY() const {return p_y; };

    //coordinate polari
    double getR() const;
    double getTheta() const;

    //calcolo distanza da un altro punto
    double distanza(const Posizione& ) const;
    double distanza(const double x, const double y) const;
    
    protected:

    double p_x, p_y;

};