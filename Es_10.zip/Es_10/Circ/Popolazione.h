#pragma once

#include "Percorso.h"

using namespace std;

class Popolazione : public Percorso {

    public:

        Popolazione() {Npaths = 0;} ;
        Popolazione(unsigned int, Percorso&, Random&);
        Popolazione(unsigned int, vector<Percorso>&);
        Popolazione(unsigned int, vector<Citta>&, Random&);

        ~Popolazione() {};

        void operator=(Popolazione& p)
        {
            Npaths = p.getNPaths();
            for(unsigned int i = 0; i < Npaths; i++)
                pop[i] = p.getPathN(i);
        }

        double getNPaths() const {return Npaths; };
        vector<Percorso> getPop() {return pop; };
        Percorso getPathN(unsigned int N) {return pop[N]; };
        void setPathN(unsigned int N, Percorso p) {pop[N] = p; };
        unsigned int PbcPop(unsigned int N) {return N%Npaths; };

        void CrossingOver(Popolazione&, Random&);
        void Ordina(void);
        void Mutazione(Random&);
        unsigned int Selezione(Random&);
    
        void Generazione(Random&, Popolazione&);

    protected:
        vector<Percorso> pop;
        unsigned int Npaths;
        double mutageno = 0.1;
        double crssover = 0.;
};