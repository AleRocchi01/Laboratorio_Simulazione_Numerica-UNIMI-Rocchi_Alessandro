#include "Percorso.h"
#include <cmath>
#include <iostream>

Percorso::Percorso(unsigned int c)
{
    Ncities = c;

    // Crea percorso base
    for(unsigned int i = 0; i < Ncities; i++)
    {
        Citta cit(0, 0, 0);
        path.push_back(cit);
    }
   
}

Percorso::Percorso(unsigned int c, vector<Citta>& p, Random& rnd)
{
    Ncities = c;

    // Crea percorso 
    for(unsigned int i = 0; i < Ncities; i++)
        path.push_back(p[i]);

    for(unsigned int i = 1; i < getNCities(); i++)
        PermPair(i, rnd);
}

void Percorso::PermPair(unsigned int j, Random& rnd)
{
    unsigned int i = Pbc(j + rnd.Rannyu(1, Ncities - 1));   
    swap(path[i], path[j]);
}

void Percorso::Shift(Random& rnd)
{
    // shift di n
    unsigned int n = (unsigned int) rnd.Rannyu(1, Ncities-1);
    // per m città consecutive
    unsigned int m = (unsigned int) rnd.Rannyu(1, Ncities);
    // città iniziale
    unsigned int in = (unsigned int) rnd.Rannyu(1, Ncities);

    for(unsigned int i = 0; i < n; i++)
        for(int j = (m-1); j >= 0; j--)
            swap(path[Pbc(j + in + i)], path[Pbc(j + in + i + 1)]);
}

void Percorso::PermCont(Random& rnd)
{
    // m città continue
    unsigned int m = (unsigned int) rnd.Rannyu(1, (unsigned int)(Ncities+1)/2);
    // prima città primo gruppo 
    unsigned int frst = (unsigned int) rnd.Rannyu(1, Ncities);
    // prima città secondo gruppo
    unsigned int scnd = Pbc((unsigned int) rnd.Rannyu(m+frst, frst+Ncities-m));

    for(unsigned int i = 0; i < m; i++)
        swap(path[Pbc(frst + i)], path[Pbc(scnd + i)]);
}

void Percorso::Inversion(Random& rnd)
{
    // m città continue
    unsigned int m = (unsigned int) rnd.Rannyu(1, (unsigned int)Ncities);
    // città iniziale
    unsigned int in = (unsigned int) rnd.Rannyu(1, (unsigned int)Ncities);

    for(unsigned int i = 0; i < m/2; i++)
        swap(path[Pbc(in + i)], path[Pbc(in + m - 1 - i)]);
}

double Percorso::Lenght(void)
{
    double dep = 0;

    for(unsigned int i = 0; i < Ncities - 1; i++)
        dep += sqrt(abs(pow(path[i].getX() - path[i+1].getX(), 2) + pow(path[i].getY() - path[i+1].getY(), 2)));

    dep += sqrt(abs(pow(path[Ncities - 1].getX() - path[0].getX(), 2) + pow(path[Ncities - 1].getY() - path[0].getY(), 2)));    
    return dep;
}

unsigned int Percorso::Pbc(unsigned int n)
{
    if(n < Ncities) return n;
    else{
        unsigned int N = n % (Ncities-1);
        if(N==0) return Ncities-1;
        else return N;
    }
}
