#include "Popolazione.h"
#include "mpi.h"

#include <vector>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <sstream>

using namespace std;

void Print(Percorso&);
void InputRnd(Random&, int&, int&, int, int*);
double AverageBest(Popolazione&, unsigned int);

int main(int argc, char* argv[]) {

    // Il programma è relativo all'esercizio 2

    int size, rank;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    MPI_Status stat;

    Random rnd;
    int p1, p2;
    int seed[4];
    InputRnd(rnd, p1, p2, rank, seed);

    unsigned int Ncities = 50;
    
    vector<Citta> citta(Ncities);

    ifstream in("American_capitals.data");
    if (in.is_open()!=1) cerr << "PROBLEM: Unable to open Primes" << endl;
    double x, y;
    
    for(unsigned int i = 0; i < Ncities; i++)
    {
        in >> x >> y;
        Citta dep(i, x, y);
        citta[i] = dep;
    }

    in.close();

    // cambio i primes per avere gen di num casuali diversi
    ifstream Primes("Primes");
    if (Primes.is_open()){
        string line;
        for(int i = 0; i < rank; i++) getline(Primes, line);
        Primes >> p1 >> p2;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();
    rnd.SetRandom(seed,p1,p2);

    unsigned int Npop = 201;
    
    Popolazione popodd(Npop, citta, rnd);
    Popolazione popevn = popodd;
    
    unsigned int Ngen = 1000;
    unsigned int migration = 10;

    ofstream out;
    if(rank == 0)
        out.open("America-Lbest.dat", ios::app);

    int wd = 16;
    int Nbest = 50;
    int tratta[size]; 


    for(unsigned int i = 0; i < Ngen; i++)
    {
        if(rank == 0 && i%100 == 0 && i!=0)
            cout << i/10 << "%\n";

        popodd.Generazione(rnd, popevn);
        if(rank==0) 
            out << setw(wd) << popevn.getPathN(0).Lenght() << setw(wd) << AverageBest(popevn, Nbest) << endl;
        
        popevn.Generazione(rnd, popodd);
        if(rank==0) 
            out << setw(wd) << popodd.getPathN(0).Lenght() << setw(wd) << AverageBest(popodd, Nbest) << endl;

        if (i % migration == 0)
        {
            if(rank == 0 )
                for(int g = 0; g < size; g ++)
                    tratta[g] = rnd.Rannyu(0,size); 
            
            MPI_Bcast(tratta, size, MPI_INTEGER, 0, MPI_COMM_WORLD); 
            MPI_Barrier(MPI_COMM_WORLD);

            int migrante[Ncities]; 
            int arrivo[Ncities];

            for(int h = 0; h < Ncities; h++)
            {
                migrante[h] = popodd.getPathN(0).getCityN(h).getName(); 
                arrivo[h] = 0;
            }

            for(int h=0; h < size; h++)
            {
                Percorso path(Ncities, citta, rnd);

                if(rank == h)
                    MPI_Send(&migrante[0], Ncities, MPI_INTEGER, tratta[h], 0, MPI_COMM_WORLD);

                if(rank == tratta[h])
                    MPI_Recv(&arrivo[0], Ncities, MPI_INTEGER, h, 0, MPI_COMM_WORLD, &stat);

                int counter = 0;

                for (int g = 0; g < Ncities; g++)
                    if (arrivo[g] == 0)
                        counter++;

                if (counter != Ncities)
                {

                    for (int j = 0; j < Ncities; j++)
                    {
                        for (int k = 0; k < Ncities; k++)
                        {
                            if (arrivo[j] == citta[k].getName())
                            {
                                x = citta[k].getX();
                                y = citta[k].getY();
                            }
                        }

                        Citta citt(arrivo[j], x, y);
                        path.setCityN(citt, j);
                    }

                    popodd.setPathN(Npop-1, path);
                }
            }
            popodd.Ordina(); 
        }
    }
    
    if(rank == 0)
        out.close();


    popodd.Ordina();

    if(rank == 0)
    {
        out.open("America-city.dat", ios::app);    

        Percorso p = popodd.getPathN(0);
    
        for(unsigned int j = 0; j < Ncities;j++)
            out << setw(wd) << p.getCityN(j).getName()<< setw(wd) << p.getCityN(j).getX() << setw(wd) << setw(wd) << p.getCityN(j).getY() << endl;

        out << setw(wd) << p.getCityN(0).getName()<< setw(wd) << p.getCityN(0).getX() << setw(wd) << setw(wd) << p.getCityN(0).getY() << endl;

        out.close();
    }
    
    MPI_Finalize();
    
    return 0;
}

void Print(Percorso& path){
    for(int j = 0; j < path.getNCities();j++)
        cout << path.getCityN(j).getName() << " ";

    cout << endl << "Lenght: " << path.Lenght() << endl;
}

void InputRnd(Random& rnd, int& p1, int& p2, int rank, int* seed)
{
    string line;
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        }
        input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;
}

double AverageBest(Popolazione& p, unsigned int N)
{
    double ave = 0;
    for(unsigned int i = 0; i < N; i++)
        ave += p.getPathN(i).Lenght();
    
    return ave/(double)N;
}
