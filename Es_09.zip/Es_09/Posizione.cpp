#include "Posizione.h"
#include <cmath>

using namespace std;
 
Posizione::Posizione() : p_x{}, p_y{} {}

Posizione::Posizione(double x, double y) : p_x{x}, p_y{y} {}

Posizione::Posizione(const Posizione& b) : p_x{b.getX()}, p_y{b.getY()} {}

double Posizione::getR() const 
{
    return sqrt(pow(p_x, 2) + pow(p_y, 2));    
}

double Posizione::getTheta() const 
{
    return atan2(p_y, p_x);
}

double Posizione::distanza(const Posizione& b) const 
{
    return sqrt( pow((p_x - b.getX()), 2) +
                 pow((p_y - b.getY()), 2) );
 
}

double Posizione::distanza(const double x, const double y) const 
{
    return sqrt( pow((p_x - x), 2) +
                 pow((p_y - y), 2) ); 
}
