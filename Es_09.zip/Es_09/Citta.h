#pragma once

#include "Posizione.h"

class Citta : public Posizione {

public:

  Citta() : Posizione{}, name{} {};
  Citta(unsigned int nm, const Posizione& p) : Posizione(p), name{nm} {};
  Citta(unsigned int nm, double x, double y) : Posizione(x, y), name{nm} {};
  Citta(const Citta& c) : Posizione(c.getX(), c.getY()), name{c.getName()} {};

  ~Citta() {};

  void operator=(Citta c)
  {
    name = c.getName();
    p_x = c.getX();
    p_y = c.getY();
  }

  void setName(unsigned int nm) {name = nm; };
  unsigned int getName() const {return name; };
    

  protected:
    unsigned int name;
};