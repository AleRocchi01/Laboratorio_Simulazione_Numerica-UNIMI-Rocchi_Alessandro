#include "Popolazione.h"
#include <cmath>
#include <iostream>

Popolazione::Popolazione(unsigned int c, Percorso& p, Random& rnd)
{
    Npaths = c;
    Percorso path(p);
    // Crea popolazione
    for(unsigned int i = 0; i < Npaths; i++)
    {
        for(unsigned int i = 1; i < getNCities(); i++)
            path.PermPair(i, rnd);
        pop.push_back(path);
    }
   
}

Popolazione::Popolazione(unsigned int c, vector<Percorso>& p)
{
    Npaths = c;

    // Crea popolazione 
    for(unsigned int i = 0; i < Npaths; i++)
        pop.push_back(p[i]);

}

Popolazione::Popolazione(unsigned int c, vector<Citta>& v, Random& rnd)
{
    Npaths = c;
    // Crea popolazione
    for(unsigned int i = 0; i < Npaths; i++)
    {
        Percorso path(v.size(), v, rnd);
        pop.push_back(path);
    }
   
}

void Popolazione::CrossingOver(Popolazione& popf, Random& rnd)
{
    // ciclo su tutta la popolazione
    for(unsigned int i = 0; i < Npaths/2; i++)
    {
        // Selezione padre e madre
        unsigned int padre = Selezione(rnd);
        unsigned int madre = Selezione(rnd);

        // Copio i genitori nei figli        
        popf.setPathN(2 * i, pop[padre]);
        popf.setPathN(2 * i + 1, pop[madre]);

        // Con probabilità "crssover" applico il crossingover ai figli e lascio inalterati i genitori
        if(rnd.Rannyu() < crssover)
        {
            unsigned int cut = (unsigned int) rnd.Rannyu(1, Ncities-1);

            unsigned int index1 = 0;
            unsigned int index2 = 0;

            for(unsigned int j = 1; j < Ncities; j++)
            {
                for(unsigned int k = cut + 1; k < Ncities; k++)
                {
                    // Ciclo sugli elementi del padre dopo il taglio, confronto
                    // con gli elementi della madre seguendo l'ordine della madre.
                    // Se trovo corrispondenza salvo l'elemento della madre, copio la 
                    // città nel percorso figlio, nella posizione indicata da "index1".
                    // Reciprocamente per il secondo figlio. 
                    if(pop[padre].getCityN(k).getName() == pop[madre].getCityN(j).getName())
                    {
                        index1++;
                        popf.getPathN(2*i).getCityN(cut+index1) = pop[madre].getCityN(j);
                    }

                    if(pop[madre].getCityN(k).getName() == pop[padre].getCityN(j).getName())
                    {
                        index2++;
                        popf.getPathN(2*i + 1).getCityN(cut+index2) = pop[padre].getCityN(j);
                    }
                }
            }
        }
    }
}

void Popolazione::Ordina(void)
{
    // Ordina la popolazione dal più corto al più lungo
    for(unsigned int j = 0; j < Npaths; j++)
        for(unsigned int k = j + 1; k < Npaths; k++)
            if(pop[j].Lenght() > pop[k].Lenght())
                swap(pop[j], pop[k]);
}

void Popolazione::Mutazione(Random& rnd)
{
    // Muta la popolazione con probabilità "mutageno" e in caso di mutazione
    // sceglie una mutazione a caso tra le 4 possibili
    for(unsigned int i = 0; i < Npaths; i++)
    {
        if(rnd.Rannyu() < mutageno)
        {
            int mut = (int) rnd.Rannyu(0, 4);
            switch(mut)
            {
                case 0:
                    pop[i].PermPair((int)rnd.Rannyu(1, Ncities), rnd);
                    break;
                case 1:
                    pop[i].Shift(rnd);
                    break;
                case 2:
                    pop[i].PermCont(rnd);
                    break;
                case 3:
                    pop[i].Inversion(rnd);
                    break;
                default:
                    break;
            }
        }
    }
}

unsigned int Popolazione::Selezione(Random& rnd)
{
    // Seleziona un elemento della popolazione 
    // privilegiando gli elementi a lunghezza minore
    int p = 3;
    return (unsigned int) (Npaths * pow(rnd.Rannyu(), p));
}

void Popolazione::Generazione(Random& rnd, Popolazione& pop2)
{
    // Applico le mutazioni, poi gli elementi della popolazione
    // avranno dei figli che subiranno il crossing over.
    //
    // La scelta è stata fatta per non avere troppi vettori 
    // creati e distrutti in continuazione e per semplificare 
    // il crossingover. 
    Mutazione(rnd);
    Ordina();
    CrossingOver(pop2, rnd);
    pop2.Ordina();
}