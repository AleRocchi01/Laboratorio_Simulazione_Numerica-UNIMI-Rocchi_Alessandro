#pragma once

#include <vector>
#include <fstream>

#include "Citta.h"
#include "random.h"

using namespace std;

class Percorso : public Citta {

public:

  Percorso() {Ncities = 0;} ;
  Percorso(unsigned int);
  Percorso(unsigned int, vector<Citta>&, Random&);

  ~Percorso() {};

  void operator=(Percorso p)
  {
    Ncities = p.getNCities();
    for(unsigned int i = 0; i < Ncities; i++)
      path[i] = p.getCityN(i);
  }

  double getNCities() const {return Ncities; };
  vector<Citta> getPath() {return path; };
  Citta getCityN(unsigned int N) {return path[N]; };

  void PermPair(unsigned int, Random&);

  void Shift(Random&);

  void PermCont(Random&);

  void Inversion(Random&);

  double Lenght(void);

  unsigned int Pbc(unsigned int);

  protected:
    vector<Citta> path;
    unsigned int Ncities;
};