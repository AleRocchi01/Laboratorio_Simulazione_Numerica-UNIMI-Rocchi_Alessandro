#include "Popolazione.h"

#include <vector>
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void Print(Percorso&);
void InputRnd(Random&, int&, int&, int*);
double AverageBest(Popolazione&, unsigned int);

int main() {
   
    // Il programma è relativo all'esercizio 1

    // Setup generatore numeri casuali
    Random rnd;
    int p1, p2;
    int seed[4];
    InputRnd(rnd, p1, p2, seed);

    // Creazione delle città    
    vector<Citta> cittaC;
    vector<Citta> cittaQ;
    unsigned int Ncities = 34;

    for(unsigned int i = 0; i < Ncities; i++)
    {
        {
            double theta = rnd.Rannyu(0, 2*M_PI);
            Citta dep(i, cos(theta), sin(theta));
            cittaC.push_back(dep);
        }

        {
            double x = rnd.Rannyu();
            double y = rnd.Rannyu();
            Citta dep(i, x, y);
            cittaQ.push_back(dep);
        }
    }

    // Creazione della popolazione
    unsigned int Npop = 200;
    
    Popolazione popoddC(Npop, cittaC, rnd);
    Popolazione popevnC = popoddC;

    Popolazione popoddQ(Npop, cittaQ, rnd);
    Popolazione popevnQ = popoddQ;
    
    unsigned int Ngen = 300;

    ofstream outC, outQ;
    outC.open("circ-Lbest.dat", ios::app);
    outQ.open("quad-Lbest.dat", ios::app);

    int wd = 16;
    unsigned int Nbest = 50;

    // Evoluzione della popolazione
    // Salvataggio dello storico della lunghezza del percorso migliore per ciascuna generazione
    for(unsigned int i = 0; i < Ngen; i++)
    {
        popoddC.Generazione(rnd, popevnC);
        outC << setw(wd) << popevnC.getPathN(0).Lenght() << setw(wd) << AverageBest(popevnC, Nbest) << endl;

        popevnC.Generazione(rnd, popoddC);
        outC << setw(wd) << popoddC.getPathN(0).Lenght() << setw(wd) << AverageBest(popoddC, Nbest) << endl;

        popoddQ.Generazione(rnd, popevnQ);
        outQ << setw(wd) << popevnQ.getPathN(0).Lenght() << setw(wd) << AverageBest(popevnQ, Nbest) << endl;
        
        popevnQ.Generazione(rnd, popoddQ);
        outQ << setw(wd) << popoddQ.getPathN(0).Lenght() << setw(wd) << AverageBest(popoddQ, Nbest) << endl;
    }
    
    outC.close();
    outQ.close();

    popoddC.Ordina();
    popoddQ.Ordina();

    // Salvataggio del percorso migliore alla fine dell'evoluzione
    outC.open("circ-city.dat", ios::app);
    outQ.open("quad-city.dat", ios::app);

    Percorso pC = popoddC.getPathN(0);
    Percorso pQ = popoddQ.getPathN(0);
    
    for(unsigned int j = 0; j < Ncities;j++)
    {
        outC << setw(wd) << pC.getCityN(j).getName()<< setw(wd) << pC.getCityN(j).getX() << setw(wd) << setw(wd) << pC.getCityN(j).getY() << endl;
        outQ << setw(wd) << pQ.getCityN(j).getName()<< setw(wd) << pQ.getCityN(j).getX() << setw(wd) << setw(wd) << pQ.getCityN(j).getY() << endl;
    }

    outC << setw(wd) << pC.getCityN(0).getName()<< setw(wd) << pC.getCityN(0).getX() << setw(wd) << setw(wd) << pC.getCityN(0).getY() << endl;
    outQ << setw(wd) << pQ.getCityN(0).getName()<< setw(wd) << pQ.getCityN(0).getX() << setw(wd) << setw(wd) << pQ.getCityN(0).getY() << endl;

    outC.close();
    outQ.close();
    
    return 0;
}

void Print(Percorso& path){
    //for(int j = 0; j < path.getNCities();j++)
      //  cout << path.getCityN(j).getName() << " ";

    cout << endl << "Lenght: " << path.Lenght() << endl;
}

void InputRnd(Random& rnd, int& p1, int& p2, int* seed)
{
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        }
        input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;
}

double AverageBest(Popolazione& p, unsigned int N)
{
    double ave = 0;
    for(unsigned int i = 0; i < N; i++)
        ave += p.getPathN(i).Lenght();
    
    return ave/(double)N;
}
