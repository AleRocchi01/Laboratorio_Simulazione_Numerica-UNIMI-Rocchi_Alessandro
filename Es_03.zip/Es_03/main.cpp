#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <cmath>

#include "random.h"
#include "funzioni.h"

using namespace std;
 
int main (int argc, char *argv[]){

    // Il programma è relativo all'esercizio 1

    // Set-up generatore numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2 ;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        }
        input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;

    // Inizializzazione variabili 
    const int M{10000};
    const int N{100};
    const int L{(int) M / N};
    
    double ST{};
    double call{};
    double put{};

    double S0{100.};
    double T{1.};
    double K{100.}; // Prezzo fissato per la compravendita
    double r{0.1};
    double sigma{0.25};
    
    array<double, N> avecall;
    array<double, N> ave2call;
        
    array<double, N> sum_progcall;
    sum_progcall.fill(0);
    array<double, N> sum2_progcall;
    sum2_progcall.fill(0);
    array<double, N> err_progcall;

    array<double, N> aveput;
    array<double, N> ave2put;

    array<double, N> sum_progput;
    sum_progput.fill(0);
    array<double, N> sum2_progput;
    sum2_progput.fill(0);
    array<double, N> err_progput;

    // Creazione dati "direct sampling"

    for(int i{}; i < N; i++){
        for(int j{}; j < L; j++){
            ST = S0 * exp((r - 0.5 * pow(sigma, 2)) * T + sigma * rnd.Gauss(0, 1) * sqrt(T));
            if(0 < ST - K){
                call += exp(-r * T) * (ST - K);  // Aumenta di max[0, S(t)-k]
            }else{
                put += exp(-r * T) * (K - ST);   // Aumenta di max[0, k-S(t)]
            }
            ST = 0;
        }
            
        avecall[i] = call / L;
        ave2call[i] = pow(avecall[i], 2);   
             
        aveput[i] = put / L;
        ave2put[i] = pow(aveput[i], 2);
    
        call = 0;
        put = 0;
    }

    // Analisi e salvataggio dati
    ofstream of;
    of.open("measures-ST.out");
    if(!of.is_open())
        cerr << "PROBLEM: Unable to open \"measures-st.out\"" << endl;
    
    for(int i{}; i < N; i++){
        for(int j{}; j < i + 1; j++){
            sum_progcall[i] += avecall[j];
            sum2_progcall[i] += ave2call[j];
            
            sum_progput[i] += aveput[j];
            sum2_progput[i] += ave2put[j];
        }
        sum_progcall[i] /= (i + 1);
        sum2_progcall[i] /= (i + 1);
        sum_progput[i] /= (i + 1);
        sum2_progput[i] /= (i + 1);
        
        err_progcall[i] = error(sum_progcall[i], sum2_progcall[i], i); // Statistical uncertainty
        err_progput[i] = error(sum_progput[i], sum2_progput[i], i); // Statistical uncertainty
        of << sum_progcall[i] << " " << err_progcall[i] << " " << sum_progput[i] << " " << err_progput[i] << endl;
    }

    of.close();

    // Reset vettori per l'analisi    
    sum_progcall.fill(0);
    sum2_progcall.fill(0);
    sum_progput.fill(0);
    sum2_progput.fill(0);

    // Creazione dati "path sampling"

    double t{T / 100.};

    for(int i{}; i < N; i++){
        for(int j{}; j < L; j++){
            for(int l{}; l < 100; l++){
                if(l == 0){
                    ST = S0 * exp((r - 0.5 * pow(sigma, 2)) * t + sigma * rnd.Gauss(0, 1) * sqrt(t)); 
                }else{
                    ST = ST * exp((r - 0.5 * pow(sigma, 2)) * t + sigma * rnd.Gauss(0, 1) * sqrt(t)); 
                }
            }
            if(0 < ST - K){
                call += exp(-r * T) * (ST - K);
            }else{
                put += exp(-r * T) * (K - ST);
            }
            ST = 0;
        }
            
        avecall[i] = call / L;
        ave2call[i] = pow(avecall[i], 2);   
             
        aveput[i] = put / L;
        ave2put[i] = pow(aveput[i], 2);

        call = 0;
        put = 0;
    }

    // Analisi e salvataggio dati
    of.open("measures-st.out");
    if(!of.is_open())
        cerr << "PROBLEM: Unable to open \"measures-st.out\"" << endl;
        
    for(int i{}; i < N; i++){
        for(int j{}; j < i + 1; j++){
            sum_progcall[i] += avecall[j];
            sum2_progcall[i] += ave2call[j];
            
            sum_progput[i] += aveput[j];
            sum2_progput[i] += ave2put[j];
        }
        sum_progcall[i] /= (i + 1);
        sum2_progcall[i] /= (i + 1);
        sum_progput[i] /= (i + 1);
        sum2_progput[i] /= (i + 1);
        
        err_progcall[i] = error(sum_progcall[i], sum2_progcall[i], i); // Statistical uncertainty
        err_progput[i] = error(sum_progput[i], sum2_progput[i], i); // Statistical uncertainty
        of << sum_progcall[i] << " " << err_progcall[i] << " " << sum_progput[i] << " " << err_progput[i] << endl;
    }

    of.close();

    return 0;
}
