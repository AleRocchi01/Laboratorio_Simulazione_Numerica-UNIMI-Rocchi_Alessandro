#include <array>
#include <cmath>

#include "random.h"

using namespace std;

class needle{
    private:
        double m_needle_lenght;
        double m_interv_lenght;

    public:
        needle() : m_needle_lenght(0.1), m_interv_lenght(1.) {}
        needle(double tot_lenght, double lenght) : m_needle_lenght(lenght), m_interv_lenght(tot_lenght) {}
        ~needle() {}

        array<double, 2> extract(Random &gen){
            double x, y;
            for(;;){
                x = gen.Rannyu(-1., 1.);
                y = gen.Rannyu(-1, 1.);
                if(pow(x, 2) + pow(y, 2) < 1)
                    break;
            }
        
            array<double, 2> res{gen.Rannyu(0., m_interv_lenght), m_needle_lenght * x / sqrt(pow(x, 2) + pow(y, 2))};

            return res;
        }

        bool check(double inf_bound, double sup_bound, array<double, 2> extracted){
        
            // checking start position
            if (extracted[0] < inf_bound || extracted[0] > sup_bound)
                return false;

            // checking if crosses
            double tmp = extracted[0] + extracted[1];
            if (tmp < inf_bound || tmp > sup_bound)
                return true;
            
            return false;
        }

        const double needle_lenght() { return m_needle_lenght; }
        const double interv_lenght() { return m_interv_lenght; }
};

template <size_t N> double extimate_pi(needle &ned, Random &gen, const array<double, N> &interval, const int max_throws) {
    
    int counter {};
    
    for (int i{}; i < max_throws; i++){
        for (auto j = interval.cbegin(); j < interval.cend() - 1; j++)
            counter += ned.check(*(j), *(j + 1), ned.extract(gen));
    }

    return (2. * ned.needle_lenght() * max_throws) / (counter * ned.interv_lenght() / (N - 1));
}
