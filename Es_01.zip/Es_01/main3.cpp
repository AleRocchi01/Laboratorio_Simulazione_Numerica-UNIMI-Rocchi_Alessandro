#include <iostream>
#include <fstream>
#include <string>
#include <array>

#include "random.h"
#include "functions.h"
#include "needle.h"

using namespace std;

int main(){

    // Il programma è relativo all'esercizio 3

    // Set up generatore numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("primes32001.in");
    if (Primes.is_open())
    {
        Primes >> p1 >> p2;
    }
    else
        cerr << "PROBLEM: Unable to open Primes" << std::endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open())
    {
        while (!input.eof())
        {
            input >> property;
            if (property == "RANDOMSEED")
            {
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed, p1, p2);
            }
        }
        input.close();
    }
    else
        cerr << "PROBLEM: Unable to open seed.in" << std::endl;

    // DATA
    constexpr double lenght{1.}; // Lunghezza ago
    constexpr int n_interval{5}; // Numero di maglie

    // Inizializzazione array con intervalli
    array<double, n_interval + 1> interval;

    for (int i{}; i < n_interval; i++)
        interval[i] = i * (lenght / n_interval);
    
    interval[n_interval] = lenght;

    // Estrazione e calcolo PI

    needle ned(lenght, lenght / (2. * n_interval));

    constexpr int M{10000};
    constexpr int N{100};
    constexpr int L{M / N};

    array<double, N> ave;
    array<double, N> ave2;
    array<double, N> sum_prog;
    sum_prog.fill(0);
    array<double, N> sum2_prog;
    sum2_prog.fill(0);
    array<double, N> err_prog;
    
    cout << "Starting pi calculation...\n";

    for(int i{}; i < N; i++){
        double sum1{};
        for(int j{0}; j < L; j++)
            sum1 += extimate_pi(ned, rnd, interval, M);

        ave[i] = sum1 / L;        // pi_i
        ave2[i] = pow(ave[i], 2); // (pi_i)^2
        
        switch(i){
            case 20 :
                cout << "20%\n";
                break;
            case 40 :
                cout << "40%\n";
                break;
            case 60 :
                cout << "60%\n";
                break;
            case 80 :
                cout << "80%\n";
                break;
        }
    }

    // Scrittura su file dati PI
    ofstream of;

    of.open("datapi.out");
   
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"datapi.out\"" << endl;

    for(int i{}; i < N; i++){
        for(int j{}; j < i + 1; j++){
            sum_prog[i] += ave[j];        // SUM_{j=0,i} r_j
            sum2_prog[i] += ave2[j];      // SUM_{j=0,i} (r_j)^2
        }
        sum_prog[i]/=(i+1);             // Cumulative average
        sum2_prog[i]/=(i+1);            // Cumulative square average
        err_prog[i] = error(sum_prog[i], sum2_prog[i], i); // Statistical uncertainty
        of << sum_prog[i] << " " << sum2_prog[i] << " " << err_prog[i] << endl;
    }
   
    of.close();

    return 0;
}
