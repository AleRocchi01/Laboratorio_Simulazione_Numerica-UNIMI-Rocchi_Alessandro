#pragma once

#include <cmath>
#include <iomanip>
#include <fstream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <string>

using namespace std;

// Funzione per la stima dell'incertezza statistica
double error(double AV, double AV2, int n){
    if(n==0)
        return 0;
    else
        return sqrt(abs(AV2 - pow(AV, 2)) / n);
}

// Funzione per dividere un vettore per uno scalare 
void DivideVectorByScalar(vector<int> &v, int k){
     for_each(v.begin(), v.end(), [k](int &c){ c /= k; });
}
  

// calcola l'ordine di grandezza di un numero
int OrdineGrandezza(const double number){
  if(1 < fabs(number) && fabs(number) < 10)
    return 0;

  double dep{number};
  int i{};
  for(;;){
 
    if(fabs(dep) > 10){
      dep = dep / 10;
      i++;

    }else{
      dep = dep * 10;
      i--; 
    }

    if(fabs(dep) < 10 && fabs(dep) > 1)
      return i;
  }
};

// fornisce il segno di un numero tramite i valori -1, 1 e 0
int segno(double b) {
    if(b < 0)
        return -1;
    else if(b == 0)
        return 0;
    else
        return 1;
};

// funzioni per l'interpolazione
double interp(vector<double> ptA, vector<double> ptB, double y){
    return ptA[0] + (ptB[0] - ptA[0]) / (ptB[1]- ptA[1]) * (y - ptA[1]);
}

double interp(vector<double> ptA, vector<double> ptB){
    return interp(ptA, ptB, 0);
}

double interp(double ptAx, double ptAy, double ptBx, double ptBy, double y){
    return ptAx + (ptBx - ptAx) / (ptBy- ptAy) * (y - ptAy);
}

double interp(double ptAx, double ptAy, double ptBx, double ptBy){
    return interp(ptAx, ptAy, ptBx, ptBy, 0);
}

// calcola la pendenza della retta in un grafico a scala logaritmica
double LogSlope(vector<double> inizio, vector<double> fine){
    double deltax{log(fine[0]) - log(inizio[0])};
    double deltay{log(fine[1]) - log(inizio[1])};

    return deltay / deltax;    
}