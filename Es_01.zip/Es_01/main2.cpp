#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <cmath>

#include "random.h"
#include "functions.h"

double error(double AV, double AV2, int n);


using namespace std;
 
int main (int argc, char *argv[]){

    // Il programma è relativo all'esercizio 2

    // Set up generatore numeri casuali
    Random rnd;
    int seed[4];
    int p1, p2;
    ifstream Primes("Primes");
    if (Primes.is_open()){
        Primes >> p1 >> p2 ;
    } else cerr << "PROBLEM: Unable to open Primes" << endl;
    Primes.close();

    ifstream input("seed.in");
    string property;
    if (input.is_open()){
        while ( !input.eof() ){
            input >> property;
            if( property == "RANDOMSEED" ){
                input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
                rnd.SetRandom(seed,p1,p2);
            }
        } 
    input.close();
    } else cerr << "PROBLEM: Unable to open seed.in" << endl;

    // 01.2.2
    // Definizione variabili
    int M{10000};                   // Totale numeri estratti
    array<int, 4> x{1, 2, 10, 100}; // Numero N di estrazioni sommate

    // Distribuzione gaussiana
    ofstream of;
    of.open("data4std.out");
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"data4std.out\"" << endl;
    
    double sum2{};
    double sum10{};
    double sum100{};
    
    for(int i{}; i < M; i++){
        double dep{};

        for(int j{}; j < x[3] - x[2]; j++)
            sum100 += rnd.Gauss();

        for(int j{}; j < x[2] - x[1]; j++){
            dep = rnd.Gauss();
            sum100 += dep;
            sum10 += dep;
        }        

        for(int j{}; j < x[1] - x[0]; j++){
            dep = rnd.Gauss();
            sum100 += dep;
            sum10 += dep;
            sum2 += dep;
        }
        dep = rnd.Gauss();
        sum100 += dep;
        sum10 += dep;
        sum2 += dep;
        of << dep << " " << sum2 / x[1] << " " << sum10 / x[2] << " " << sum100 / x[3] << endl;
    
        sum2 = 0;
        sum10 = 0;
        sum100 = 0;
    }

    of.close();

    // Distribuzione esponenziale
    of.open("data4exp.out");
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"data4exp.out\"" << endl;
    
    sum2 = 0;
    sum10 = 0;
    sum100 = 0;
    
    for(int i{}; i < M; i++){
        double dep{};

        for(int j{}; j < x[3] - x[2]; j++)
            sum100 += rnd.Exp();

        for(int j{}; j < x[2] - x[1]; j++){
            dep = rnd.Exp();
            sum100 += dep;
            sum10 += dep;
        }        

        for(int j{}; j < x[1] - x[0]; j++){
            dep = rnd.Exp();
            sum100 += dep;
            sum10 += dep;
            sum2 += dep;
        }
        dep = rnd.Exp();
        sum100 += dep;
        sum10 += dep;
        sum2 += dep;
        of << dep << " " << sum2 / x[1] << " " << sum10 / x[2] << " " << sum100 / x[3] << endl;
    
        sum2 = 0;
        sum10 = 0;
        sum100 = 0;
    }
    
    of.close();

    // Distribuzione di Cauchy
    of.open("data4cau.out");
    if (!of.is_open())
        cerr << "PROBLEM: Unable to open \"data4cau.out\"" << endl;
    
    sum2 = 0;
    sum10 = 0;
    sum100 = 0;
    
    for(int i{}; i < M; i++){
        double dep{};

        for(int j{}; j < x[3] - x[2]; j++)
            sum100 += rnd.Cauchy();

        for(int j{}; j < x[2] - x[1]; j++){
            dep = rnd.Cauchy();
            sum100 += dep;
            sum10 += dep;
        }        

        for(int j{}; j < x[1] - x[0]; j++){
            dep = rnd.Cauchy();
            sum100 += dep;
            sum10 += dep;
            sum2 += dep;
        }
        dep = rnd.Cauchy();
        sum100 += dep;
        sum10 += dep;
        sum2 += dep;
        of << dep << " " << sum2 / x[1] << " " << sum10 / x[2] << " " << sum100 / x[3] << endl;
    
        sum2 = 0;
        sum10 = 0;
        sum100 = 0;
    }
    
    of.close();

    return 0;
}
