#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <vector>
#include <cmath>
#include "random.h"
#include "functions.h"

using namespace std;
 
int main (){

   // Il programma è relativo all'esercizio 1

   // Set up generatore numeri casuali
   Random rnd;
   int seed[4];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

   // Definizione variabili
   int M{1000000};             // Totale numeri estratti
   const int N{100};           // Numero di blocchi
   const int L = int(M/N);     // Numero di estrazioni per ciascun blocco
   
   array<double, N> ave;
   array<double, N> ave2;
   array<double, N> sum_prog;
   sum_prog.fill(0);
   array<double, N> sum2_prog;
   sum2_prog.fill(0);
   array<double, N> err_prog;

   double dep;

   // Generazione misure e salvataggio su file 
   ofstream of;
   of.open("measures.out");
   if (!of.is_open())
      cerr << "PROBLEM: Unable to open \"measures.out\"" << endl;
   
   for(int i{}; i < N; i++){
      double sum{};
      for(int j{0}; j < L; j++){
         dep = rnd.Rannyu();
         sum += dep;
         if(j == L -1 && i == N - 1){
            of << dep;
         }else of << dep << endl;
      }
      ave[i] = sum / L;        // r_i
      ave2[i] = pow(ave[i], 2); // (r_i)^2
   }

   of.close();

   // 01.1.1
   // Calcolo media cumulativa e sua uncertezza, salvataggio su file
   of.open("data1.out");
   
   if (!of.is_open())
      cerr << "PROBLEM: Unable to open \"data1.out\"" << endl;

   for(int i{}; i < N; i++){
      for(int j{}; j < i + 1; j++){
        sum_prog[i] += ave[j];        // SUM_{j=0,i} r_j
        sum2_prog[i] += ave2[j];      // SUM_{j=0,i} (r_j)^2
      }
      sum_prog[i]/=(i+1);             // Cumulative average
      sum2_prog[i]/=(i+1);            // Cumulative square average
      err_prog[i] = error(sum_prog[i], sum2_prog[i], i); // Statistical uncertainty
      of << sum_prog[i] << " " << sum2_prog[i] << " " << err_prog[i] << endl;
   }
   
   of.close();

   // 01.1.2
   // Lettura misure da file 
   ifstream inf;
   inf.open("measures.out");
   if (!inf.is_open())
      cerr << "PROBLEM: Unable to open \"measures.out\"" << endl;

   for(int i{}; i < N; i++){
      double sum{};
      for(int j{}; j < L; j++){
         inf >> dep;
         sum += pow(dep - 0.5, 2);  // Accumulate measures
      }
      ave[i] = sum / L;         // Estimate in each block 
      ave2[i] = pow(ave[i], 2); 
   }

   inf.close();

   // Calcolo stima dello scarto quadratico medio e 
   // della sua incertezza, salvataggio su file
   sum_prog.fill(0);
   sum2_prog.fill(0);

   of.open("data2.out");
   
   if (!of.is_open())
      cerr << "PROBLEM: Unable to open \"data2.out\"" << endl;

   for(int i{}; i < N; i++){
      for(int j{}; j < i + 1; j++){
         sum_prog[i] += ave[j];
         sum2_prog[i] += ave2[j];
      }
      sum_prog[i] /= (i+1);              // Cumulative average
      sum2_prog[i] /= (i+1);             // Cumulative square average
      err_prog[i] = error(sum_prog[i], sum2_prog[i], i); // Statistical uncertainty
      of << sum_prog[i] << " " << err_prog[i] << endl;
   }

   of.close();

   // 01.1.3
   M = 100;
   int n{10000};
   vector<double> chij;

   // Lettura misure da file e calcolo chi^2
   inf.open("measures.out");
   if (!inf.is_open())
      cerr << "PROBLEM: Unable to open \"measures.out\"" << endl;

   for(;;){
      
      vector<int> ni(M, 0);

      for(int i{}; i < n; i++){
         inf >> dep;
         int bin{(int) (M * dep)};
         ni[bin]++;
      }

      double chip{};
      for(int i{}; i < M; i++){
         chip += pow(ni[i] - (n/M), 2) / (n/M);
      }

      chij.push_back(chip);

      chip = 0;

      if(inf.eof())
         break;
   }

   inf.close();

   // Salvataggio su file
   of.open("data3.out");

   if (!of.is_open())
      cerr << "PROBLEM: Unable to open \"data3.out\"" << endl;
   
   for(int i{}; i < 100; i++)
      of << chij[i] << endl;
   
   of.close();
   

   rnd.SaveSeed();
   return 0;
}
