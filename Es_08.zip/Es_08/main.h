// Random numbers
#include "random.h"
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int seed[4];
Random rnd;

// parameters, observables
double mu_old, sigma_old;
double mu_new, sigma_new;
double T, beta;
double E_old = 0;
double E_old_Error = 0;
double E_new = 0;
double E_new_Error = 0;
int accepted; // Variabili per il secondo Metropolis
int attempted;

double E_best, E_best_Error;
double mu_best, sigma_best;

double delta_annealing;

// pigreco
const double pi = 3.1415927;

// Integral parameters
double deltaInt;
int acceptedInt;
int attemptedInt;
double stimaInt;
int nblkInt, nstepInt, npointInt, nEn;
double x_old, x_new;
double mu, sigma;

// functions
void Input(void);
void Reset(int);
void Accumulate(void);
void Averages(int);
void Metropolis();
void Histo_Fill();

double Integral(double, double);
double Psi(double);
double HPsi(double);
void InputInt(double, double);
void ResetInt(void);
void Energy(double&, double&, double, double);
double Error(double, double, int);

void MediaEnergia(fstream&);



