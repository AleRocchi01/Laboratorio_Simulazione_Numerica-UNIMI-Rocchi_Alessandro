#include <iostream>
#include <fstream>
#include <array>
#include "random.h"
#include "main.h"

using namespace std;

// SIMULATED ANNEALING

int main()
{

  // Il programma è relativo all'esercizio 2

  fstream Energies;
  fstream mu_sigma;

  Energies.open("Energies.dat", ios::app);

  if(!Energies.is_open())
    cerr << "PROBLEM: Unable to open \"Energies.dat\"" << endl;

  mu_sigma.open("mu-sigma.dat", ios::app);

  if(!Energies.is_open())
    cerr << "PROBLEM: Unable to open \"mu-sigma.dat\"" << endl;

  Input();                      // Settaggio parametri letti da file input
  for (int i = 1; i < 50; i++) // ciclo sulle temperature
  {
    if (i == 1)
    { // alla prima temperatura E_old non è conosciuta, da qui in poi questa parte di codice diventa superflua
      Energy(E_old, E_old_Error, mu_old, sigma_old);
      E_best = E_old;
      E_best_Error = E_best_Error;
    }

    // movimento in mu e sigma

    mu_new = mu_old + delta_annealing * (rnd.Rannyu() - 0.5);       // classe integral gia dotata di rnd. Spostamento in mu
    sigma_new = sigma_old + delta_annealing * (rnd.Rannyu() - 0.5); // Spostamento in sigma

    Energy(E_new, E_new_Error, mu_new, sigma_new);

    Metropolis();
    cout << "Temperatura = " << T << endl;  
    cout << "---------------------------\n";

    if(E_old < E_best)
    {
      E_best = E_old;
      E_best_Error = E_old_Error;
      mu_best = mu_old;
      sigma_best = sigma_old;
    }

    T -= T / 10; // aggiornamento temperatura e beta
    beta = 1. / T;

    if(i!=0 && (i%40) == 0) delta_annealing /= 2;



    Energies << i << " " << E_old << " " << E_old_Error << endl; // stampa a file
    mu_sigma << i << " " << mu_old << " " << sigma_old << endl;
  }

  Energies.close();
  mu_sigma.close();

  MediaEnergia(Energies);

  double x_old = 0;
  double x_new = 0;
  fstream histo;
  
  // saving data for histogram

  histo.open("histo.dat", ios::app);

  for (int i = 0; i < 100000; i++)
  {
    x_new = x_old + deltaInt * (rnd.Rannyu() - 0.5);
    double Prob = pow(Psi(x_new) / Psi(x_old), 2);
    if (rnd.Rannyu() < Prob)
    {
      x_old = x_new;
    }
    histo << x_old << endl;
  }

  // closing files
  Energies.close();
  mu_sigma.close();
  histo.close();

  return 0;
}

void Input(void)
{
  //Read seed for random numbers
  int p1, p2;
  ifstream Primes("Primes");
  Primes >> p1 >> p2 ;
  Primes.close();

  ifstream input("seed.in");
  input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
  rnd.SetRandom(seed,p1,p2);
  input.close();

  ifstream ReadInput;
  // Read input informations
  ReadInput.open("input3.in");

  ReadInput >> delta_annealing;

  ReadInput >> mu_old;
  mu_best = mu_old;
  ReadInput >> sigma_old;
  sigma_best = sigma_old;

  ReadInput >> T;

  ReadInput >> nblkInt;
  ReadInput >> nstepInt;
  ReadInput >> npointInt;
  ReadInput >> deltaInt;
  ReadInput >> nEn;

  beta = 1. / T;

  cout << "The program perform Metropolis Integration" << endl;
  cout << "Moves parameter = " << deltaInt << endl;
  cout << "Number of blocks = " << nblkInt << endl;
  cout << "Number of steps in one block = " << nstepInt << endl
       << "-------------------------------------------\n";
  ReadInput.close();

  return;
}

void Metropolis()
{
  double K = -beta * (E_new - E_old);
  if (rnd.Rannyu() < exp(K))
  {
    mu_old = mu_new;
    sigma_old = sigma_new;
    E_old = E_new;
    E_old_Error = E_new_Error;
    accepted++;
  }

  attempted++;

  cout << "Acceptance rate = " << (double) accepted/attempted << endl;
}

double Integral(double a, double b)
{
    double Gn;
    InputInt(a, b);

    double Ave = 0;
    
    for(int i{}; i < nblkInt; i++){
        x_old = 0;
        double step{};

        for(int k{}; k < nstepInt; k++){
        
            Gn = 0;
            for(int j{}; j < npointInt; j++)
            {
                x_new = deltaInt * (rnd.Rannyu() - 0.5) + x_old;
                double A = pow(Psi(x_new) / Psi(x_old), 2);
            
                if(A>rnd.Rannyu())
                    x_old = x_new;
    
                Gn += HPsi(x_old) / Psi(x_old);
            }
            step += Gn/npointInt;
        }

        Ave += step / nstepInt;
    }

    double result = Ave / nblkInt;
    
    return result;
}

double Psi(double x)
{
    double a = -pow((x - mu) / sigma, 2) / 2.;
    double b = -pow((x + mu) / sigma, 2) / 2.;
    return exp(a) + exp(b);
}

double HPsi(double x)
{
    double a = exp(-pow((x - mu) / sigma, 2) / 2.);
    double b = exp(-pow((x + mu) / sigma, 2) / 2.);
    
    double T = (a * (pow((x - mu), 2) - sigma*sigma) + b * (pow((x + mu), 2) - sigma*sigma)) / (-2 * pow(sigma, 4));
    double V = (pow(x, 4) - 2.5 * pow(x, 2)) * Psi(x);

    return T + V;
}

void InputInt(double a, double b)
{  
    stimaInt = 0;
    acceptedInt = 0;
    attemptedInt = 0;
    mu = a;
    sigma  = b;
}

void ResetInt(void)
{
    stimaInt = 0;
    acceptedInt = 0;
    attemptedInt = 0;
}

void Energy(double &E, double &Er, double mu, double sigma)
{
  double sum = 0;
  double sum2 = 0;

  for(int i = 0; i < nEn ; i++)
  {
    double dep = Integral(mu, sigma);
    sum += dep;
    sum2 += dep*dep;
  }

  E = sum / nEn;
  Er = Error(sum, sum2, nEn);
}

double Error(double sum, double sum2, int iblk)
{
  if(iblk == 1)
  {
    return 0;
  }else
  {
    return sqrt(fabs(sum2/(double)iblk - pow(sum/(double)iblk,2))/(double)(iblk - 1));
  }
}

double error(double sum, double sum2, int iblk)
{
  if(iblk == 1)
  {
    return 0;
  }else
  {
    return sqrt(fabs(sum2 - pow(sum,2))/(double)(iblk - 1));
  }
}

void MediaEnergia(fstream& Energies)
{
  const int N{100};
  const int L{20};
    
  array<double, N> ave;
  array<double, N> ave2;
  array<double, N> sum_prog;
  sum_prog.fill(0);
  array<double, N> sum2_prog;
  sum2_prog.fill(0);
  array<double, N> err_prog;

  cout << "\nValori migliori di mu e sigma:\n";
  cout << "mu = " << mu_best;
  cout << "\nsigma = " << sigma_best << endl;

  cout << "\nCalcolo valore energia migliore...\n";
  
  for(int i{}; i < N; i++)
  {
    if(i%10==0 && i!=0)cout<<i<<"%\n";

    double dep = 0;

    for(int j{}; j < L; j++)
      dep += Integral(mu_best, sigma_best);
      
    ave[i] = dep/L;
    ave2[i] = pow(ave[i], 2);
  }

  cout << "100%\n";

  // Calcolo media e incertezza, scrittura dei risultati su file
  Energies.open("Best_E.dat", ios::app);
  if(!Energies.is_open())
    cerr << "PROBLEM: Unable to open \"Best_E.dat\"" << endl;
    
  for(int i = 0; i < N; i++)
  {
    for(int j = 0; j <= i; j++)
    {
      sum_prog[i] += ave[j];
      sum2_prog[i] += ave2[j];
    }
    sum_prog[i] /= (i + 1);
    sum2_prog[i] /= (i + 1);
    err_prog[i] = error(sum_prog[i], sum2_prog[i], i+1); // Statistical uncertainty
    Energies << i << " " << sum_prog[i] << " " << err_prog[i] << endl;
  }    

  // closing files
  Energies.close();
}
